import WelcomeController from './WelcomeController'
import GroupController from './GroupController'
import InvitationController from './InvitationController'
import WishlistController from './WishlistController'
import Settings from './Settings'
const Controllers = {
    WelcomeController: Object.assign(WelcomeController, WelcomeController),
GroupController: Object.assign(GroupController, GroupController),
InvitationController: Object.assign(InvitationController, InvitationController),
WishlistController: Object.assign(WishlistController, WishlistController),
Settings: Object.assign(Settings, Settings),
}

export default Controllers