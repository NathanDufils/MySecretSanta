import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\GroupController::show
 * @see app/Http/Controllers/GroupController.php:18
 * @route '/groups/{group}'
 */
export const show = (args: { group: number | { id: number } } | [group: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/groups/{group}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\GroupController::show
 * @see app/Http/Controllers/GroupController.php:18
 * @route '/groups/{group}'
 */
show.url = (args: { group: number | { id: number } } | [group: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { group: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { group: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    group: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        group: typeof args.group === 'object'
                ? args.group.id
                : args.group,
                }

    return show.definition.url
            .replace('{group}', parsedArgs.group.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\GroupController::show
 * @see app/Http/Controllers/GroupController.php:18
 * @route '/groups/{group}'
 */
show.get = (args: { group: number | { id: number } } | [group: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\GroupController::show
 * @see app/Http/Controllers/GroupController.php:18
 * @route '/groups/{group}'
 */
show.head = (args: { group: number | { id: number } } | [group: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\GroupController::show
 * @see app/Http/Controllers/GroupController.php:18
 * @route '/groups/{group}'
 */
    const showForm = (args: { group: number | { id: number } } | [group: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\GroupController::show
 * @see app/Http/Controllers/GroupController.php:18
 * @route '/groups/{group}'
 */
        showForm.get = (args: { group: number | { id: number } } | [group: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\GroupController::show
 * @see app/Http/Controllers/GroupController.php:18
 * @route '/groups/{group}'
 */
        showForm.head = (args: { group: number | { id: number } } | [group: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\GroupController::store
 * @see app/Http/Controllers/GroupController.php:50
 * @route '/groups'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/groups',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\GroupController::store
 * @see app/Http/Controllers/GroupController.php:50
 * @route '/groups'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\GroupController::store
 * @see app/Http/Controllers/GroupController.php:50
 * @route '/groups'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\GroupController::store
 * @see app/Http/Controllers/GroupController.php:50
 * @route '/groups'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\GroupController::store
 * @see app/Http/Controllers/GroupController.php:50
 * @route '/groups'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\GroupController::destroy
 * @see app/Http/Controllers/GroupController.php:182
 * @route '/groups/{group}'
 */
export const destroy = (args: { group: number | { id: number } } | [group: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/groups/{group}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\GroupController::destroy
 * @see app/Http/Controllers/GroupController.php:182
 * @route '/groups/{group}'
 */
destroy.url = (args: { group: number | { id: number } } | [group: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { group: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { group: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    group: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        group: typeof args.group === 'object'
                ? args.group.id
                : args.group,
                }

    return destroy.definition.url
            .replace('{group}', parsedArgs.group.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\GroupController::destroy
 * @see app/Http/Controllers/GroupController.php:182
 * @route '/groups/{group}'
 */
destroy.delete = (args: { group: number | { id: number } } | [group: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\GroupController::destroy
 * @see app/Http/Controllers/GroupController.php:182
 * @route '/groups/{group}'
 */
    const destroyForm = (args: { group: number | { id: number } } | [group: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\GroupController::destroy
 * @see app/Http/Controllers/GroupController.php:182
 * @route '/groups/{group}'
 */
        destroyForm.delete = (args: { group: number | { id: number } } | [group: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
/**
* @see \App\Http\Controllers\GroupController::join
 * @see app/Http/Controllers/GroupController.php:191
 * @route '/groups/join'
 */
export const join = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: join.url(options),
    method: 'post',
})

join.definition = {
    methods: ["post"],
    url: '/groups/join',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\GroupController::join
 * @see app/Http/Controllers/GroupController.php:191
 * @route '/groups/join'
 */
join.url = (options?: RouteQueryOptions) => {
    return join.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\GroupController::join
 * @see app/Http/Controllers/GroupController.php:191
 * @route '/groups/join'
 */
join.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: join.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\GroupController::join
 * @see app/Http/Controllers/GroupController.php:191
 * @route '/groups/join'
 */
    const joinForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: join.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\GroupController::join
 * @see app/Http/Controllers/GroupController.php:191
 * @route '/groups/join'
 */
        joinForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: join.url(options),
            method: 'post',
        })
    
    join.form = joinForm
/**
* @see \App\Http\Controllers\GroupController::update
 * @see app/Http/Controllers/GroupController.php:76
 * @route '/groups/{group}'
 */
export const update = (args: { group: number | { id: number } } | [group: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/groups/{group}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\GroupController::update
 * @see app/Http/Controllers/GroupController.php:76
 * @route '/groups/{group}'
 */
update.url = (args: { group: number | { id: number } } | [group: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { group: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { group: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    group: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        group: typeof args.group === 'object'
                ? args.group.id
                : args.group,
                }

    return update.definition.url
            .replace('{group}', parsedArgs.group.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\GroupController::update
 * @see app/Http/Controllers/GroupController.php:76
 * @route '/groups/{group}'
 */
update.put = (args: { group: number | { id: number } } | [group: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\GroupController::update
 * @see app/Http/Controllers/GroupController.php:76
 * @route '/groups/{group}'
 */
    const updateForm = (args: { group: number | { id: number } } | [group: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\GroupController::update
 * @see app/Http/Controllers/GroupController.php:76
 * @route '/groups/{group}'
 */
        updateForm.put = (args: { group: number | { id: number } } | [group: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\GroupController::addParticipant
 * @see app/Http/Controllers/GroupController.php:91
 * @route '/groups/{group}/participants'
 */
export const addParticipant = (args: { group: number | { id: number } } | [group: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: addParticipant.url(args, options),
    method: 'post',
})

addParticipant.definition = {
    methods: ["post"],
    url: '/groups/{group}/participants',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\GroupController::addParticipant
 * @see app/Http/Controllers/GroupController.php:91
 * @route '/groups/{group}/participants'
 */
addParticipant.url = (args: { group: number | { id: number } } | [group: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { group: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { group: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    group: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        group: typeof args.group === 'object'
                ? args.group.id
                : args.group,
                }

    return addParticipant.definition.url
            .replace('{group}', parsedArgs.group.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\GroupController::addParticipant
 * @see app/Http/Controllers/GroupController.php:91
 * @route '/groups/{group}/participants'
 */
addParticipant.post = (args: { group: number | { id: number } } | [group: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: addParticipant.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\GroupController::addParticipant
 * @see app/Http/Controllers/GroupController.php:91
 * @route '/groups/{group}/participants'
 */
    const addParticipantForm = (args: { group: number | { id: number } } | [group: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: addParticipant.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\GroupController::addParticipant
 * @see app/Http/Controllers/GroupController.php:91
 * @route '/groups/{group}/participants'
 */
        addParticipantForm.post = (args: { group: number | { id: number } } | [group: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: addParticipant.url(args, options),
            method: 'post',
        })
    
    addParticipant.form = addParticipantForm
/**
* @see \App\Http\Controllers\GroupController::removeParticipant
 * @see app/Http/Controllers/GroupController.php:123
 * @route '/groups/{group}/participants/{user}'
 */
export const removeParticipant = (args: { group: number | { id: number }, user: number | { id: number } } | [group: number | { id: number }, user: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: removeParticipant.url(args, options),
    method: 'delete',
})

removeParticipant.definition = {
    methods: ["delete"],
    url: '/groups/{group}/participants/{user}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\GroupController::removeParticipant
 * @see app/Http/Controllers/GroupController.php:123
 * @route '/groups/{group}/participants/{user}'
 */
removeParticipant.url = (args: { group: number | { id: number }, user: number | { id: number } } | [group: number | { id: number }, user: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    group: args[0],
                    user: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        group: typeof args.group === 'object'
                ? args.group.id
                : args.group,
                                user: typeof args.user === 'object'
                ? args.user.id
                : args.user,
                }

    return removeParticipant.definition.url
            .replace('{group}', parsedArgs.group.toString())
            .replace('{user}', parsedArgs.user.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\GroupController::removeParticipant
 * @see app/Http/Controllers/GroupController.php:123
 * @route '/groups/{group}/participants/{user}'
 */
removeParticipant.delete = (args: { group: number | { id: number }, user: number | { id: number } } | [group: number | { id: number }, user: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: removeParticipant.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\GroupController::removeParticipant
 * @see app/Http/Controllers/GroupController.php:123
 * @route '/groups/{group}/participants/{user}'
 */
    const removeParticipantForm = (args: { group: number | { id: number }, user: number | { id: number } } | [group: number | { id: number }, user: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: removeParticipant.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\GroupController::removeParticipant
 * @see app/Http/Controllers/GroupController.php:123
 * @route '/groups/{group}/participants/{user}'
 */
        removeParticipantForm.delete = (args: { group: number | { id: number }, user: number | { id: number } } | [group: number | { id: number }, user: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: removeParticipant.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    removeParticipant.form = removeParticipantForm
/**
* @see \App\Http\Controllers\GroupController::draw
 * @see app/Http/Controllers/GroupController.php:136
 * @route '/groups/{group}/draw'
 */
export const draw = (args: { group: number | { id: number } } | [group: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: draw.url(args, options),
    method: 'post',
})

draw.definition = {
    methods: ["post"],
    url: '/groups/{group}/draw',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\GroupController::draw
 * @see app/Http/Controllers/GroupController.php:136
 * @route '/groups/{group}/draw'
 */
draw.url = (args: { group: number | { id: number } } | [group: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { group: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { group: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    group: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        group: typeof args.group === 'object'
                ? args.group.id
                : args.group,
                }

    return draw.definition.url
            .replace('{group}', parsedArgs.group.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\GroupController::draw
 * @see app/Http/Controllers/GroupController.php:136
 * @route '/groups/{group}/draw'
 */
draw.post = (args: { group: number | { id: number } } | [group: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: draw.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\GroupController::draw
 * @see app/Http/Controllers/GroupController.php:136
 * @route '/groups/{group}/draw'
 */
    const drawForm = (args: { group: number | { id: number } } | [group: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: draw.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\GroupController::draw
 * @see app/Http/Controllers/GroupController.php:136
 * @route '/groups/{group}/draw'
 */
        drawForm.post = (args: { group: number | { id: number } } | [group: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: draw.url(args, options),
            method: 'post',
        })
    
    draw.form = drawForm
/**
* @see \App\Http\Controllers\GroupController::assignWishlist
 * @see app/Http/Controllers/GroupController.php:159
 * @route '/groups/{group}/wishlist'
 */
export const assignWishlist = (args: { group: number | { id: number } } | [group: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: assignWishlist.url(args, options),
    method: 'post',
})

assignWishlist.definition = {
    methods: ["post"],
    url: '/groups/{group}/wishlist',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\GroupController::assignWishlist
 * @see app/Http/Controllers/GroupController.php:159
 * @route '/groups/{group}/wishlist'
 */
assignWishlist.url = (args: { group: number | { id: number } } | [group: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { group: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { group: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    group: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        group: typeof args.group === 'object'
                ? args.group.id
                : args.group,
                }

    return assignWishlist.definition.url
            .replace('{group}', parsedArgs.group.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\GroupController::assignWishlist
 * @see app/Http/Controllers/GroupController.php:159
 * @route '/groups/{group}/wishlist'
 */
assignWishlist.post = (args: { group: number | { id: number } } | [group: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: assignWishlist.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\GroupController::assignWishlist
 * @see app/Http/Controllers/GroupController.php:159
 * @route '/groups/{group}/wishlist'
 */
    const assignWishlistForm = (args: { group: number | { id: number } } | [group: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: assignWishlist.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\GroupController::assignWishlist
 * @see app/Http/Controllers/GroupController.php:159
 * @route '/groups/{group}/wishlist'
 */
        assignWishlistForm.post = (args: { group: number | { id: number } } | [group: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: assignWishlist.url(args, options),
            method: 'post',
        })
    
    assignWishlist.form = assignWishlistForm
const GroupController = { show, store, destroy, join, update, addParticipant, removeParticipant, draw, assignWishlist }

export default GroupController