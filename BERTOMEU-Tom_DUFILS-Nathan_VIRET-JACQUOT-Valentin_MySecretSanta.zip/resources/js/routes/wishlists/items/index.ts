import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\WishlistController::add
 * @see app/Http/Controllers/WishlistController.php:42
 * @route '/wishlists/{wishlist}/items'
 */
export const add = (args: { wishlist: number | { id: number } } | [wishlist: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: add.url(args, options),
    method: 'post',
})

add.definition = {
    methods: ["post"],
    url: '/wishlists/{wishlist}/items',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\WishlistController::add
 * @see app/Http/Controllers/WishlistController.php:42
 * @route '/wishlists/{wishlist}/items'
 */
add.url = (args: { wishlist: number | { id: number } } | [wishlist: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { wishlist: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { wishlist: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    wishlist: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        wishlist: typeof args.wishlist === 'object'
                ? args.wishlist.id
                : args.wishlist,
                }

    return add.definition.url
            .replace('{wishlist}', parsedArgs.wishlist.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\WishlistController::add
 * @see app/Http/Controllers/WishlistController.php:42
 * @route '/wishlists/{wishlist}/items'
 */
add.post = (args: { wishlist: number | { id: number } } | [wishlist: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: add.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\WishlistController::add
 * @see app/Http/Controllers/WishlistController.php:42
 * @route '/wishlists/{wishlist}/items'
 */
    const addForm = (args: { wishlist: number | { id: number } } | [wishlist: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: add.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\WishlistController::add
 * @see app/Http/Controllers/WishlistController.php:42
 * @route '/wishlists/{wishlist}/items'
 */
        addForm.post = (args: { wishlist: number | { id: number } } | [wishlist: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: add.url(args, options),
            method: 'post',
        })
    
    add.form = addForm
/**
* @see \App\Http\Controllers\WishlistController::remove
 * @see app/Http/Controllers/WishlistController.php:57
 * @route '/wishlists/{wishlist}/items/{item}'
 */
export const remove = (args: { wishlist: number | { id: number }, item: number | { id: number } } | [wishlist: number | { id: number }, item: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: remove.url(args, options),
    method: 'delete',
})

remove.definition = {
    methods: ["delete"],
    url: '/wishlists/{wishlist}/items/{item}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\WishlistController::remove
 * @see app/Http/Controllers/WishlistController.php:57
 * @route '/wishlists/{wishlist}/items/{item}'
 */
remove.url = (args: { wishlist: number | { id: number }, item: number | { id: number } } | [wishlist: number | { id: number }, item: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    wishlist: args[0],
                    item: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        wishlist: typeof args.wishlist === 'object'
                ? args.wishlist.id
                : args.wishlist,
                                item: typeof args.item === 'object'
                ? args.item.id
                : args.item,
                }

    return remove.definition.url
            .replace('{wishlist}', parsedArgs.wishlist.toString())
            .replace('{item}', parsedArgs.item.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\WishlistController::remove
 * @see app/Http/Controllers/WishlistController.php:57
 * @route '/wishlists/{wishlist}/items/{item}'
 */
remove.delete = (args: { wishlist: number | { id: number }, item: number | { id: number } } | [wishlist: number | { id: number }, item: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: remove.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\WishlistController::remove
 * @see app/Http/Controllers/WishlistController.php:57
 * @route '/wishlists/{wishlist}/items/{item}'
 */
    const removeForm = (args: { wishlist: number | { id: number }, item: number | { id: number } } | [wishlist: number | { id: number }, item: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: remove.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\WishlistController::remove
 * @see app/Http/Controllers/WishlistController.php:57
 * @route '/wishlists/{wishlist}/items/{item}'
 */
        removeForm.delete = (args: { wishlist: number | { id: number }, item: number | { id: number } } | [wishlist: number | { id: number }, item: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: remove.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    remove.form = removeForm
const items = {
    add: Object.assign(add, add),
remove: Object.assign(remove, remove),
}

export default items