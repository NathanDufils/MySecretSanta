import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../wayfinder'
import items from './items'
/**
* @see \App\Http\Controllers\WishlistController::index
 * @see app/Http/Controllers/WishlistController.php:13
 * @route '/wishlists'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/wishlists',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\WishlistController::index
 * @see app/Http/Controllers/WishlistController.php:13
 * @route '/wishlists'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\WishlistController::index
 * @see app/Http/Controllers/WishlistController.php:13
 * @route '/wishlists'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\WishlistController::index
 * @see app/Http/Controllers/WishlistController.php:13
 * @route '/wishlists'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\WishlistController::index
 * @see app/Http/Controllers/WishlistController.php:13
 * @route '/wishlists'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\WishlistController::index
 * @see app/Http/Controllers/WishlistController.php:13
 * @route '/wishlists'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\WishlistController::index
 * @see app/Http/Controllers/WishlistController.php:13
 * @route '/wishlists'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\WishlistController::create
 * @see app/Http/Controllers/WishlistController.php:0
 * @route '/wishlists/create'
 */
export const create = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

create.definition = {
    methods: ["get","head"],
    url: '/wishlists/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\WishlistController::create
 * @see app/Http/Controllers/WishlistController.php:0
 * @route '/wishlists/create'
 */
create.url = (options?: RouteQueryOptions) => {
    return create.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\WishlistController::create
 * @see app/Http/Controllers/WishlistController.php:0
 * @route '/wishlists/create'
 */
create.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\WishlistController::create
 * @see app/Http/Controllers/WishlistController.php:0
 * @route '/wishlists/create'
 */
create.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: create.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\WishlistController::create
 * @see app/Http/Controllers/WishlistController.php:0
 * @route '/wishlists/create'
 */
    const createForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: create.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\WishlistController::create
 * @see app/Http/Controllers/WishlistController.php:0
 * @route '/wishlists/create'
 */
        createForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\WishlistController::create
 * @see app/Http/Controllers/WishlistController.php:0
 * @route '/wishlists/create'
 */
        createForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    create.form = createForm
/**
* @see \App\Http\Controllers\WishlistController::store
 * @see app/Http/Controllers/WishlistController.php:22
 * @route '/wishlists'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/wishlists',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\WishlistController::store
 * @see app/Http/Controllers/WishlistController.php:22
 * @route '/wishlists'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\WishlistController::store
 * @see app/Http/Controllers/WishlistController.php:22
 * @route '/wishlists'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\WishlistController::store
 * @see app/Http/Controllers/WishlistController.php:22
 * @route '/wishlists'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\WishlistController::store
 * @see app/Http/Controllers/WishlistController.php:22
 * @route '/wishlists'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\WishlistController::show
 * @see app/Http/Controllers/WishlistController.php:0
 * @route '/wishlists/{wishlist}'
 */
export const show = (args: { wishlist: string | number } | [wishlist: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/wishlists/{wishlist}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\WishlistController::show
 * @see app/Http/Controllers/WishlistController.php:0
 * @route '/wishlists/{wishlist}'
 */
show.url = (args: { wishlist: string | number } | [wishlist: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { wishlist: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    wishlist: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        wishlist: args.wishlist,
                }

    return show.definition.url
            .replace('{wishlist}', parsedArgs.wishlist.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\WishlistController::show
 * @see app/Http/Controllers/WishlistController.php:0
 * @route '/wishlists/{wishlist}'
 */
show.get = (args: { wishlist: string | number } | [wishlist: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\WishlistController::show
 * @see app/Http/Controllers/WishlistController.php:0
 * @route '/wishlists/{wishlist}'
 */
show.head = (args: { wishlist: string | number } | [wishlist: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\WishlistController::show
 * @see app/Http/Controllers/WishlistController.php:0
 * @route '/wishlists/{wishlist}'
 */
    const showForm = (args: { wishlist: string | number } | [wishlist: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\WishlistController::show
 * @see app/Http/Controllers/WishlistController.php:0
 * @route '/wishlists/{wishlist}'
 */
        showForm.get = (args: { wishlist: string | number } | [wishlist: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\WishlistController::show
 * @see app/Http/Controllers/WishlistController.php:0
 * @route '/wishlists/{wishlist}'
 */
        showForm.head = (args: { wishlist: string | number } | [wishlist: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\WishlistController::edit
 * @see app/Http/Controllers/WishlistController.php:0
 * @route '/wishlists/{wishlist}/edit'
 */
export const edit = (args: { wishlist: string | number } | [wishlist: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/wishlists/{wishlist}/edit',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\WishlistController::edit
 * @see app/Http/Controllers/WishlistController.php:0
 * @route '/wishlists/{wishlist}/edit'
 */
edit.url = (args: { wishlist: string | number } | [wishlist: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { wishlist: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    wishlist: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        wishlist: args.wishlist,
                }

    return edit.definition.url
            .replace('{wishlist}', parsedArgs.wishlist.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\WishlistController::edit
 * @see app/Http/Controllers/WishlistController.php:0
 * @route '/wishlists/{wishlist}/edit'
 */
edit.get = (args: { wishlist: string | number } | [wishlist: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\WishlistController::edit
 * @see app/Http/Controllers/WishlistController.php:0
 * @route '/wishlists/{wishlist}/edit'
 */
edit.head = (args: { wishlist: string | number } | [wishlist: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\WishlistController::edit
 * @see app/Http/Controllers/WishlistController.php:0
 * @route '/wishlists/{wishlist}/edit'
 */
    const editForm = (args: { wishlist: string | number } | [wishlist: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: edit.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\WishlistController::edit
 * @see app/Http/Controllers/WishlistController.php:0
 * @route '/wishlists/{wishlist}/edit'
 */
        editForm.get = (args: { wishlist: string | number } | [wishlist: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\WishlistController::edit
 * @see app/Http/Controllers/WishlistController.php:0
 * @route '/wishlists/{wishlist}/edit'
 */
        editForm.head = (args: { wishlist: string | number } | [wishlist: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    edit.form = editForm
/**
* @see \App\Http\Controllers\WishlistController::update
 * @see app/Http/Controllers/WishlistController.php:0
 * @route '/wishlists/{wishlist}'
 */
export const update = (args: { wishlist: string | number } | [wishlist: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put","patch"],
    url: '/wishlists/{wishlist}',
} satisfies RouteDefinition<["put","patch"]>

/**
* @see \App\Http\Controllers\WishlistController::update
 * @see app/Http/Controllers/WishlistController.php:0
 * @route '/wishlists/{wishlist}'
 */
update.url = (args: { wishlist: string | number } | [wishlist: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { wishlist: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    wishlist: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        wishlist: args.wishlist,
                }

    return update.definition.url
            .replace('{wishlist}', parsedArgs.wishlist.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\WishlistController::update
 * @see app/Http/Controllers/WishlistController.php:0
 * @route '/wishlists/{wishlist}'
 */
update.put = (args: { wishlist: string | number } | [wishlist: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})
/**
* @see \App\Http\Controllers\WishlistController::update
 * @see app/Http/Controllers/WishlistController.php:0
 * @route '/wishlists/{wishlist}'
 */
update.patch = (args: { wishlist: string | number } | [wishlist: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\WishlistController::update
 * @see app/Http/Controllers/WishlistController.php:0
 * @route '/wishlists/{wishlist}'
 */
    const updateForm = (args: { wishlist: string | number } | [wishlist: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\WishlistController::update
 * @see app/Http/Controllers/WishlistController.php:0
 * @route '/wishlists/{wishlist}'
 */
        updateForm.put = (args: { wishlist: string | number } | [wishlist: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
            /**
* @see \App\Http\Controllers\WishlistController::update
 * @see app/Http/Controllers/WishlistController.php:0
 * @route '/wishlists/{wishlist}'
 */
        updateForm.patch = (args: { wishlist: string | number } | [wishlist: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\WishlistController::destroy
 * @see app/Http/Controllers/WishlistController.php:33
 * @route '/wishlists/{wishlist}'
 */
export const destroy = (args: { wishlist: number | { id: number } } | [wishlist: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/wishlists/{wishlist}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\WishlistController::destroy
 * @see app/Http/Controllers/WishlistController.php:33
 * @route '/wishlists/{wishlist}'
 */
destroy.url = (args: { wishlist: number | { id: number } } | [wishlist: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { wishlist: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { wishlist: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    wishlist: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        wishlist: typeof args.wishlist === 'object'
                ? args.wishlist.id
                : args.wishlist,
                }

    return destroy.definition.url
            .replace('{wishlist}', parsedArgs.wishlist.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\WishlistController::destroy
 * @see app/Http/Controllers/WishlistController.php:33
 * @route '/wishlists/{wishlist}'
 */
destroy.delete = (args: { wishlist: number | { id: number } } | [wishlist: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\WishlistController::destroy
 * @see app/Http/Controllers/WishlistController.php:33
 * @route '/wishlists/{wishlist}'
 */
    const destroyForm = (args: { wishlist: number | { id: number } } | [wishlist: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\WishlistController::destroy
 * @see app/Http/Controllers/WishlistController.php:33
 * @route '/wishlists/{wishlist}'
 */
        destroyForm.delete = (args: { wishlist: number | { id: number } } | [wishlist: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const wishlists = {
    index: Object.assign(index, index),
create: Object.assign(create, create),
store: Object.assign(store, store),
show: Object.assign(show, show),
edit: Object.assign(edit, edit),
update: Object.assign(update, update),
destroy: Object.assign(destroy, destroy),
items: Object.assign(items, items),
}

export default wishlists