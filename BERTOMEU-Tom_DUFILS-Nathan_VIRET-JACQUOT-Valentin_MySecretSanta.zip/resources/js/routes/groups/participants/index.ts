import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\GroupController::add
 * @see app/Http/Controllers/GroupController.php:91
 * @route '/groups/{group}/participants'
 */
export const add = (args: { group: number | { id: number } } | [group: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: add.url(args, options),
    method: 'post',
})

add.definition = {
    methods: ["post"],
    url: '/groups/{group}/participants',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\GroupController::add
 * @see app/Http/Controllers/GroupController.php:91
 * @route '/groups/{group}/participants'
 */
add.url = (args: { group: number | { id: number } } | [group: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { group: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { group: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    group: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        group: typeof args.group === 'object'
                ? args.group.id
                : args.group,
                }

    return add.definition.url
            .replace('{group}', parsedArgs.group.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\GroupController::add
 * @see app/Http/Controllers/GroupController.php:91
 * @route '/groups/{group}/participants'
 */
add.post = (args: { group: number | { id: number } } | [group: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: add.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\GroupController::add
 * @see app/Http/Controllers/GroupController.php:91
 * @route '/groups/{group}/participants'
 */
    const addForm = (args: { group: number | { id: number } } | [group: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: add.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\GroupController::add
 * @see app/Http/Controllers/GroupController.php:91
 * @route '/groups/{group}/participants'
 */
        addForm.post = (args: { group: number | { id: number } } | [group: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: add.url(args, options),
            method: 'post',
        })
    
    add.form = addForm
/**
* @see \App\Http\Controllers\GroupController::remove
 * @see app/Http/Controllers/GroupController.php:123
 * @route '/groups/{group}/participants/{user}'
 */
export const remove = (args: { group: number | { id: number }, user: number | { id: number } } | [group: number | { id: number }, user: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: remove.url(args, options),
    method: 'delete',
})

remove.definition = {
    methods: ["delete"],
    url: '/groups/{group}/participants/{user}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\GroupController::remove
 * @see app/Http/Controllers/GroupController.php:123
 * @route '/groups/{group}/participants/{user}'
 */
remove.url = (args: { group: number | { id: number }, user: number | { id: number } } | [group: number | { id: number }, user: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    group: args[0],
                    user: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        group: typeof args.group === 'object'
                ? args.group.id
                : args.group,
                                user: typeof args.user === 'object'
                ? args.user.id
                : args.user,
                }

    return remove.definition.url
            .replace('{group}', parsedArgs.group.toString())
            .replace('{user}', parsedArgs.user.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\GroupController::remove
 * @see app/Http/Controllers/GroupController.php:123
 * @route '/groups/{group}/participants/{user}'
 */
remove.delete = (args: { group: number | { id: number }, user: number | { id: number } } | [group: number | { id: number }, user: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: remove.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\GroupController::remove
 * @see app/Http/Controllers/GroupController.php:123
 * @route '/groups/{group}/participants/{user}'
 */
    const removeForm = (args: { group: number | { id: number }, user: number | { id: number } } | [group: number | { id: number }, user: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: remove.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\GroupController::remove
 * @see app/Http/Controllers/GroupController.php:123
 * @route '/groups/{group}/participants/{user}'
 */
        removeForm.delete = (args: { group: number | { id: number }, user: number | { id: number } } | [group: number | { id: number }, user: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: remove.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    remove.form = removeForm
const participants = {
    add: Object.assign(add, add),
remove: Object.assign(remove, remove),
}

export default participants