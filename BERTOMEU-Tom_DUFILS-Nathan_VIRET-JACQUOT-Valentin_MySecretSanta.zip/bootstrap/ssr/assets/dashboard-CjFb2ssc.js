import { jsxs, jsx } from "react/jsx-runtime";
import { useId } from "react";
import { A as AppLayout } from "./app-layout-BM_Stf8L.js";
import { useForm, Head, Link } from "@inertiajs/react";
import { B as Button } from "./button-BgedwMt5.js";
import { L as Label, I as Input } from "./label-C5ThrQzA.js";
import { Users, Gift } from "lucide-react";
import "@radix-ui/react-slot";
import "class-variance-authority";
import "@radix-ui/react-dialog";
import "@radix-ui/react-tooltip";
import "./dropdown-menu-DZJMNHNV.js";
import "@radix-ui/react-dropdown-menu";
import "@radix-ui/react-avatar";
import "clsx";
import "tailwind-merge";
import "@radix-ui/react-label";
function PlaceholderPattern({ className }) {
  const patternId = useId();
  return /* @__PURE__ */ jsxs("svg", { className, fill: "none", children: [
    /* @__PURE__ */ jsx("defs", { children: /* @__PURE__ */ jsx("pattern", { id: patternId, x: "0", y: "0", width: "10", height: "10", patternUnits: "userSpaceOnUse", children: /* @__PURE__ */ jsx("path", { d: "M-3 13 15-5M-5 5l18-18M-1 21 17 3" }) }) }),
    /* @__PURE__ */ jsx("rect", { stroke: "none", fill: `url(#${patternId})`, width: "100%", height: "100%" })
  ] });
}
const breadcrumbs = [
  {
    title: "Tableau de bord Santa",
    href: "/dashboard"
  }
];
function Dashboard() {
  const { data, setData, post, processing, errors } = useForm({
    code: ""
  });
  const handleJoin = (e) => {
    e.preventDefault();
    post("/groups/join");
  };
  return /* @__PURE__ */ jsxs(AppLayout, { breadcrumbs, children: [
    /* @__PURE__ */ jsx(Head, { title: "Tableau de bord" }),
    /* @__PURE__ */ jsxs("div", { className: "flex flex-1 flex-col gap-8 p-8", children: [
      /* @__PURE__ */ jsxs("div", { className: "rounded-3xl bg-gradient-to-br from-[#D42426] to-[#8C1819] p-8 text-white shadow-xl relative overflow-hidden", children: [
        /* @__PURE__ */ jsxs("div", { className: "relative z-10", children: [
          /* @__PURE__ */ jsx("h1", { className: "text-4xl font-bold mb-4 font-christmas", children: "Ho Ho Ho ! Bienvenue 🎅" }),
          /* @__PURE__ */ jsx("p", { className: "text-red-100 max-w-xl text-lg mb-8", children: "Prêt à organiser le meilleur Secret Santa ? Rejoignez un groupe existant ou créez le vôtre pour commencer les festivités !" }),
          /* @__PURE__ */ jsx("div", { className: "flex flex-wrap gap-4", children: /* @__PURE__ */ jsxs("form", { onSubmit: handleJoin, className: "flex items-end gap-2 bg-white/10 p-2 rounded-xl backdrop-blur-sm border border-white/20", children: [
            /* @__PURE__ */ jsxs("div", { className: "grid gap-1.5", children: [
              /* @__PURE__ */ jsx(Label, { htmlFor: "code", className: "text-xs font-semibold text-white/80 ml-1", children: "Code du Groupe" }),
              /* @__PURE__ */ jsx(
                Input,
                {
                  id: "code",
                  placeholder: "EX: A1B2C3",
                  className: "bg-white/90 border-0 text-black placeholder:text-gray-400 w-32 uppercase font-mono font-bold",
                  value: data.code,
                  onChange: (e) => setData("code", e.target.value),
                  maxLength: 6
                }
              )
            ] }),
            /* @__PURE__ */ jsx(Button, { type: "submit", disabled: processing, className: "bg-[#165B33] hover:bg-[#124d2b] text-white shadow-lg", children: "Rejoindre" })
          ] }) }),
          errors.code && /* @__PURE__ */ jsx("p", { className: "mt-2 text-sm font-bold text-[#F8B803]", children: errors.code })
        ] }),
        /* @__PURE__ */ jsx("div", { className: "absolute right-0 bottom-0 text-9xl opacity-10 pointer-events-none", children: "🎄" })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "grid auto-rows-min gap-4 md:grid-cols-3", children: [
        /* @__PURE__ */ jsxs("div", { className: "relative aspect-video overflow-hidden rounded-xl border border-sidebar-border/70 dark:border-sidebar-border p-6 flex flex-col justify-end bg-gradient-to-t from-orange-50 to-white", children: [
          /* @__PURE__ */ jsx(Users, { className: "w-10 h-10 text-orange-500 mb-2 opacity-80" }),
          /* @__PURE__ */ jsx("h3", { className: "text-xl font-bold text-gray-800", children: "Mes Groupes" }),
          /* @__PURE__ */ jsx("p", { className: "text-gray-500 mb-4", children: "Gérez vos événements." })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "relative aspect-video overflow-hidden rounded-xl border border-sidebar-border/70 dark:border-sidebar-border p-6 flex flex-col justify-end bg-gradient-to-t from-blue-50 to-white", children: [
          /* @__PURE__ */ jsx(Gift, { className: "w-10 h-10 text-blue-500 mb-2 opacity-80" }),
          /* @__PURE__ */ jsx("h3", { className: "text-xl font-bold text-gray-800", children: "Ma Wishlist" }),
          /* @__PURE__ */ jsx("p", { className: "text-gray-500 mb-4", children: "Ajoutez vos souhaits." }),
          /* @__PURE__ */ jsx(Link, { href: "/wishlists", className: "text-sm font-semibold text-blue-600 hover:underline", children: "Gérer ma liste →" })
        ] }),
        /* @__PURE__ */ jsx("div", { className: "relative aspect-video overflow-hidden rounded-xl border border-sidebar-border/70 dark:border-sidebar-border", children: /* @__PURE__ */ jsx(PlaceholderPattern, { className: "absolute inset-0 size-full stroke-neutral-900/20 dark:stroke-neutral-100/20" }) })
      ] })
    ] })
  ] });
}
export {
  Dashboard as default
};
