import { jsxs, jsx, Fragment } from "react/jsx-runtime";
import { T as TextLink } from "./text-link-DonLRFlI.js";
import { B as Button } from "./button-BgedwMt5.js";
import { S as Spinner } from "./spinner-2dXGZH9Y.js";
import { A as AuthLayout, a as logout } from "./auth-layout-odaDh4mC.js";
import { s as send } from "./index-BVZoIs4X.js";
import { Head, Form } from "@inertiajs/react";
import "@radix-ui/react-slot";
import "class-variance-authority";
import "clsx";
import "tailwind-merge";
import "lucide-react";
import "./useSnowflakes-Cquv3aof.js";
import "react";
import "./index--D7ld9AJ.js";
function VerifyEmail({ status }) {
  return /* @__PURE__ */ jsxs(
    AuthLayout,
    {
      title: "Vérifier l'email",
      description: "Veuillez vérifier votre adresse email en cliquant sur le lien que nous venons de vous envoyer.",
      children: [
        /* @__PURE__ */ jsx(Head, { title: "Vérifiez votre Email Père Noël" }),
        status === "verification-link-sent" && /* @__PURE__ */ jsx("div", { className: "mb-4 text-center text-sm font-medium text-green-600", children: "Un nouveau lien de vérification a été envoyé à l'adresse email que vous avez fournie lors de l'inscription." }),
        /* @__PURE__ */ jsx(Form, { ...send.form(), className: "space-y-6 text-center", children: ({ processing }) => /* @__PURE__ */ jsxs(Fragment, { children: [
          /* @__PURE__ */ jsxs(Button, { disabled: processing, variant: "secondary", children: [
            processing && /* @__PURE__ */ jsx(Spinner, {}),
            "Renvoyer l'email de vérification"
          ] }),
          /* @__PURE__ */ jsx(
            TextLink,
            {
              href: logout(),
              className: "mx-auto block text-sm",
              children: "Déconnexion"
            }
          )
        ] }) })
      ]
    }
  );
}
export {
  VerifyEmail as default
};
