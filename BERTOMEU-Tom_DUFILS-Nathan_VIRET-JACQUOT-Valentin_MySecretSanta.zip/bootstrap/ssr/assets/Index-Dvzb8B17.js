import { jsxs, jsx } from "react/jsx-runtime";
import { A as AppLayout } from "./app-layout-BM_Stf8L.js";
import { useForm, Head, router } from "@inertiajs/react";
import { Plus, Trash2, ExternalLink } from "lucide-react";
import { useState } from "react";
import "@radix-ui/react-slot";
import "class-variance-authority";
import "./button-BgedwMt5.js";
import "clsx";
import "tailwind-merge";
import "@radix-ui/react-dialog";
import "@radix-ui/react-tooltip";
import "./dropdown-menu-DZJMNHNV.js";
import "@radix-ui/react-dropdown-menu";
import "@radix-ui/react-avatar";
function Index({ wishlists }) {
  const { data, setData, post, processing, reset } = useForm({
    title: ""
  });
  const [selectedWishlistId, setSelectedWishlistId] = useState(wishlists.length > 0 ? wishlists[0].id : null);
  const selectedWishlist = wishlists.find((list) => list.id === selectedWishlistId) || (wishlists.length > 0 ? wishlists[0] : null);
  const submit = (e) => {
    e.preventDefault();
    post("/wishlists", {
      onSuccess: () => {
        reset();
      }
    });
  };
  const deleteWishlist = (id) => {
    if (confirm("Are you sure?")) {
      router.delete(`/wishlists/${id}`);
      if (selectedWishlistId === id) {
        setSelectedWishlistId(null);
      }
    }
  };
  return /* @__PURE__ */ jsxs(
    AppLayout,
    {
      breadcrumbs: [
        { title: "Dashboard", href: "/dashboard" },
        { title: "My Wishlists", href: "/wishlists" }
      ],
      children: [
        /* @__PURE__ */ jsx(Head, { title: "Wishlists" }),
        /* @__PURE__ */ jsx("div", { className: "py-12", children: /* @__PURE__ */ jsxs("div", { className: "max-w-7xl mx-auto sm:px-6 lg:px-8", children: [
          /* @__PURE__ */ jsx("h2", { className: "font-semibold text-xl text-gray-800 leading-tight mb-6", children: "My Wishlists" }),
          /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-1 md:grid-cols-3 gap-6", children: [
            /* @__PURE__ */ jsxs("div", { className: "bg-white overflow-hidden shadow-sm sm:rounded-lg p-6", children: [
              /* @__PURE__ */ jsx("h3", { className: "text-lg font-bold mb-4", children: "Your Lists" }),
              /* @__PURE__ */ jsxs("form", { onSubmit: submit, className: "mb-6 flex gap-2", children: [
                /* @__PURE__ */ jsx(
                  "input",
                  {
                    type: "text",
                    value: data.title,
                    onChange: (e) => setData("title", e.target.value),
                    placeholder: "New list name...",
                    className: "border-gray-300 focus:border-indigo-500 focus:ring-indigo-500 rounded-md shadow-sm w-full text-sm"
                  }
                ),
                /* @__PURE__ */ jsx(
                  "button",
                  {
                    type: "submit",
                    disabled: processing,
                    className: "bg-indigo-600 text-white p-2 rounded-md hover:bg-indigo-700",
                    children: /* @__PURE__ */ jsx(Plus, { className: "w-5 h-5" })
                  }
                )
              ] }),
              /* @__PURE__ */ jsx("ul", { className: "space-y-2", children: wishlists.map((list) => /* @__PURE__ */ jsxs(
                "li",
                {
                  className: `flex justify-between items-center p-3 rounded-md cursor-pointer ${selectedWishlist?.id === list.id ? "bg-indigo-50 border border-indigo-200" : "hover:bg-gray-50 border border-transparent"}`,
                  onClick: () => setSelectedWishlistId(list.id),
                  children: [
                    /* @__PURE__ */ jsx("span", { className: "font-medium", children: list.title }),
                    /* @__PURE__ */ jsx(
                      "button",
                      {
                        onClick: (e) => {
                          e.stopPropagation();
                          deleteWishlist(list.id);
                        },
                        className: "text-red-400 hover:text-red-600",
                        children: /* @__PURE__ */ jsx(Trash2, { className: "w-4 h-4" })
                      }
                    )
                  ]
                },
                list.id
              )) })
            ] }),
            /* @__PURE__ */ jsx("div", { className: "col-span-2 bg-white overflow-hidden shadow-sm sm:rounded-lg p-6", children: selectedWishlist ? /* @__PURE__ */ jsx(WishlistItems, { wishlist: selectedWishlist }) : /* @__PURE__ */ jsx("p", { className: "text-gray-500 text-center py-10", children: "Select or create a wishlist to manage items." }) })
          ] })
        ] }) })
      ]
    }
  );
}
function WishlistItems({ wishlist }) {
  const { data, setData, post, processing, reset, errors } = useForm({
    name: "",
    url: "",
    description: ""
  });
  const submitItem = (e) => {
    e.preventDefault();
    post(`/wishlists/${wishlist.id}/items`, {
      preserveScroll: true,
      onSuccess: () => reset()
    });
  };
  const deleteItem = (itemId) => {
    if (confirm("Remove this item?")) {
      router.delete(`/wishlists/${wishlist.id}/items/${itemId}`, {
        preserveScroll: true
      });
    }
  };
  return /* @__PURE__ */ jsxs("div", { children: [
    /* @__PURE__ */ jsxs("div", { className: "flex justify-between items-center mb-6", children: [
      /* @__PURE__ */ jsx("h3", { className: "text-xl font-bold", children: wishlist.title }),
      /* @__PURE__ */ jsxs("span", { className: "text-sm text-gray-500", children: [
        wishlist.items.length,
        " items"
      ] })
    ] }),
    /* @__PURE__ */ jsxs("form", { onSubmit: submitItem, className: "bg-gray-50 p-4 rounded-lg mb-6 border border-gray-100", children: [
      /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-4 mb-4", children: [
        /* @__PURE__ */ jsxs("div", { children: [
          /* @__PURE__ */ jsx("label", { className: "block text-sm font-medium text-gray-700", children: "Item Name" }),
          /* @__PURE__ */ jsx(
            "input",
            {
              type: "text",
              value: data.name,
              onChange: (e) => setData("name", e.target.value),
              className: "mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm",
              required: true
            }
          ),
          errors.name && /* @__PURE__ */ jsx("div", { className: "text-red-500 text-xs mt-1", children: errors.name })
        ] }),
        /* @__PURE__ */ jsxs("div", { children: [
          /* @__PURE__ */ jsx("label", { className: "block text-sm font-medium text-gray-700", children: "Link (Optional)" }),
          /* @__PURE__ */ jsx(
            "input",
            {
              type: "url",
              value: data.url,
              onChange: (e) => setData("url", e.target.value),
              className: "mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm",
              placeholder: "https://..."
            }
          ),
          errors.url && /* @__PURE__ */ jsx("div", { className: "text-red-500 text-xs mt-1", children: errors.url })
        ] })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "mb-4", children: [
        /* @__PURE__ */ jsx("label", { className: "block text-sm font-medium text-gray-700", children: "Description / Details" }),
        /* @__PURE__ */ jsx(
          "textarea",
          {
            value: data.description,
            onChange: (e) => setData("description", e.target.value),
            className: "mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm",
            rows: "2"
          }
        )
      ] }),
      /* @__PURE__ */ jsx("div", { className: "flex justify-end", children: /* @__PURE__ */ jsx(
        "button",
        {
          type: "submit",
          disabled: processing,
          className: "bg-indigo-600 text-white px-4 py-2 rounded-md hover:bg-indigo-700 text-sm font-medium",
          children: "Add Item"
        }
      ) })
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "space-y-4", children: [
      wishlist.items.length === 0 && /* @__PURE__ */ jsx("p", { className: "text-center text-gray-400 italic", children: "No items yet. Add something you want!" }),
      wishlist.items.map((item) => /* @__PURE__ */ jsxs("div", { className: "border rounded-lg p-4 flex justify-between items-start hover:shadow-sm transition-shadow", children: [
        /* @__PURE__ */ jsxs("div", { children: [
          /* @__PURE__ */ jsxs("h4", { className: "font-semibold text-lg flex items-center gap-2", children: [
            item.name,
            item.url && /* @__PURE__ */ jsx("a", { href: item.url, target: "_blank", rel: "noopener noreferrer", className: "text-indigo-500 hover:text-indigo-700", children: /* @__PURE__ */ jsx(ExternalLink, { className: "w-4 h-4" }) })
          ] }),
          item.description && /* @__PURE__ */ jsx("p", { className: "text-gray-600 mt-1 text-sm", children: item.description })
        ] }),
        /* @__PURE__ */ jsx(
          "button",
          {
            onClick: () => deleteItem(Number(item.id)),
            className: "text-gray-400 hover:text-red-500 p-1",
            children: /* @__PURE__ */ jsx(Trash2, { className: "w-5 h-5" })
          }
        )
      ] }, item.id))
    ] })
  ] });
}
export {
  Index as default
};
