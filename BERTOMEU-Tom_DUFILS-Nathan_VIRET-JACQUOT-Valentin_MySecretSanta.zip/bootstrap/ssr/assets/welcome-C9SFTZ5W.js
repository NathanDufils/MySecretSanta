import { jsx, jsxs, Fragment } from "react/jsx-runtime";
import { d as DropdownMenu, e as DropdownMenuTrigger, f as DropdownMenuContent, c as DropdownMenuItem } from "./dropdown-menu-DZJMNHNV.js";
import { Check, X, ChevronDown } from "lucide-react";
import { usePage, useForm, Head, Link, router } from "@inertiajs/react";
import { u as useSnowflakes } from "./useSnowflakes-Cquv3aof.js";
import { D as Dialog, a as DialogTrigger, b as DialogContent, g as DialogClose, c as DialogHeader, d as DialogTitle, e as DialogDescription, f as DialogFooter } from "./dialog-Dfe6QsSy.js";
import { B as Button } from "./button-BgedwMt5.js";
import { L as Label, I as Input } from "./label-C5ThrQzA.js";
import { useState } from "react";
import "@radix-ui/react-dropdown-menu";
import "@radix-ui/react-dialog";
import "@radix-ui/react-slot";
import "class-variance-authority";
import "clsx";
import "tailwind-merge";
import "@radix-ui/react-label";
function ChristmasTree() {
  return /* @__PURE__ */ jsx("div", { className: "relative flex h-full w-full items-center justify-center p-10", children: /* @__PURE__ */ jsxs("div", { className: "relative flex flex-col items-center", children: [
    /* @__PURE__ */ jsx("div", { className: "relative z-20 mb-[-10px] animate-pulse", children: /* @__PURE__ */ jsx("div", { className: "h-12 w-12 text-yellow-300 drop-shadow-[0_0_15px_rgba(253,224,71,0.8)]", children: /* @__PURE__ */ jsx("svg", { viewBox: "0 0 24 24", fill: "currentColor", className: "h-full w-full", children: /* @__PURE__ */ jsx("path", { d: "M12 2L15.09 8.26L22 9.27L17 14.14L18.18 21.02L12 17.77L5.82 21.02L7 14.14L2 9.27L8.91 8.26L12 2Z" }) }) }) }),
    /* @__PURE__ */ jsxs("div", { className: "flex flex-col items-center drop-shadow-2xl filter", children: [
      /* @__PURE__ */ jsx("div", { className: "z-10 h-0 w-0 border-b-[60px] border-l-[40px] border-r-[40px] border-b-[#0F5132] border-l-transparent border-r-transparent filter drop-shadow-lg" }),
      /* @__PURE__ */ jsx("div", { className: "-mt-8 z-0 h-0 w-0 border-b-[80px] border-l-[60px] border-r-[60px] border-b-[#146c43] border-l-transparent border-r-transparent filter drop-shadow-lg" }),
      /* @__PURE__ */ jsx("div", { className: "-mt-8 z-0 h-0 w-0 border-b-[100px] border-l-[80px] border-r-[80px] border-b-[#198754] border-l-transparent border-r-transparent filter drop-shadow-lg" }),
      /* @__PURE__ */ jsx("div", { className: "h-16 w-12 bg-[#3E2723] rounded-sm" })
    ] }),
    /* @__PURE__ */ jsx("div", { className: "absolute top-[60px] left-[calc(50%-10px)] h-4 w-4 rounded-full bg-red-500 shadow-lg animate-bounce duration-[2000ms]" }),
    /* @__PURE__ */ jsx("div", { className: "absolute top-[100px] right-[calc(50%-20px)] h-5 w-5 rounded-full bg-blue-400 shadow-lg animate-bounce delay-75 duration-[2200ms]" }),
    /* @__PURE__ */ jsx("div", { className: "absolute top-[140px] left-[calc(50%-30px)] h-5 w-5 rounded-full bg-yellow-400 shadow-lg animate-bounce delay-150 duration-[2500ms]" }),
    /* @__PURE__ */ jsx("div", { className: "absolute top-[80px] right-[calc(50%-15px)] h-3 w-3 rounded-full bg-purple-400 shadow-lg animate-bounce delay-300 duration-[1800ms]" }),
    /* @__PURE__ */ jsx("div", { className: "absolute top-[170px] right-[calc(50%-30px)] h-6 w-6 rounded-full bg-red-600 shadow-lg animate-bounce delay-500 duration-[2300ms]" }),
    /* @__PURE__ */ jsx("div", { className: "absolute top-[120px] left-[calc(50%+10px)] h-4 w-4 rounded-full bg-white shadow-lg animate-bounce delay-200 duration-[2100ms]" }),
    /* @__PURE__ */ jsxs("div", { className: "absolute bottom-0 flex w-[140%] justify-between px-4 translate-y-4", children: [
      /* @__PURE__ */ jsxs("div", { className: "relative h-12 w-14 bg-red-600 shadow-md", children: [
        /* @__PURE__ */ jsx("div", { className: "absolute left-[40%] h-full w-[20%] bg-yellow-400" }),
        /* @__PURE__ */ jsx("div", { className: "absolute top-[40%] h-[20%] w-full bg-yellow-400" })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "relative h-16 w-16 bg-blue-600 shadow-md -ml-6 z-10", children: [
        /* @__PURE__ */ jsx("div", { className: "absolute left-[40%] h-full w-[20%] bg-white" }),
        /* @__PURE__ */ jsx("div", { className: "absolute top-[40%] h-[20%] w-full bg-white" })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "relative h-10 w-12 bg-green-600 shadow-md", children: [
        /* @__PURE__ */ jsx("div", { className: "absolute left-[40%] h-full w-[20%] bg-red-400" }),
        /* @__PURE__ */ jsx("div", { className: "absolute top-[40%] h-[20%] w-full bg-red-400" })
      ] })
    ] })
  ] }) });
}
function Welcome({
  canRegister = true,
  groups = [],
  invitations = []
}) {
  const { auth } = usePage().props;
  const snowflakes = useSnowflakes(20);
  const smallSnowflakes = useSnowflakes(15, 8);
  const [isCreateOpen, setIsCreateOpen] = useState(false);
  const { data, setData, post, processing, errors, reset } = useForm({
    name: ""
  });
  const createGroup = (e) => {
    e.preventDefault();
    post("/groups", {
      onSuccess: () => {
        setIsCreateOpen(false);
        reset();
      }
    });
  };
  const handleAcceptInvitation = (invitationId) => {
    router.post(`/invitations/${invitationId}/accept`, {}, {
      preserveScroll: true
    });
  };
  const handleDeclineInvitation = (invitationId) => {
    if (confirm("Voulez-vous vraiment refuser cette invitation ?")) {
      router.post(`/invitations/${invitationId}/decline`, {}, {
        preserveScroll: true
      });
    }
  };
  return /* @__PURE__ */ jsxs(Fragment, { children: [
    /* @__PURE__ */ jsx(Head, { title: "Secret Santa - Ho Ho Ho!" }),
    /* @__PURE__ */ jsx("style", { children: `
                @import url('https://fonts.googleapis.com/css2?family=Mountains+of+Christmas:wght@400;700&display=swap');

                .font-christmas {
                    font-family: 'Mountains of Christmas', cursive;
                }

                .snowflake {
                    position: absolute;
                    top: -3vh;
                    color: white;
                    animation: fall linear infinite;
                }

                @keyframes fall {
                    0% { transform: translateY(-10vh) translateX(0px); opacity: 0; }
                    10% { opacity: 0.8; }
                    100% { transform: translateY(100vh) translateX(20px); opacity: 0.3; }
                }
            ` }),
    /* @__PURE__ */ jsxs("div", { className: "relative min-h-screen overflow-hidden bg-gradient-to-b from-[#D42426] to-[#8C1819] text-white selection:bg-[#F8B803] selection:text-[#391800]", children: [
      /* @__PURE__ */ jsxs("div", { "aria-hidden": "true", className: "pointer-events-none absolute inset-0 z-0 select-none", children: [
        snowflakes.map((flake, i) => /* @__PURE__ */ jsx(
          "div",
          {
            className: "snowflake text-xl",
            style: flake,
            children: "❄"
          },
          i
        )),
        smallSnowflakes.map((flake, i) => /* @__PURE__ */ jsx(
          "div",
          {
            className: "snowflake text-sm",
            style: flake,
            children: "❅"
          },
          i + 20
        ))
      ] }),
      auth.user && /* @__PURE__ */ jsxs("div", { className: "absolute right-6 top-6 z-50 flex items-center gap-4", children: [
        /* @__PURE__ */ jsxs(DropdownMenu, { children: [
          /* @__PURE__ */ jsxs(DropdownMenuTrigger, { className: "relative flex items-center justify-center rounded-full bg-white/10 p-2 text-white backdrop-blur-sm transition-colors hover:bg-white/20 focus:outline-none", children: [
            /* @__PURE__ */ jsx("span", { className: "sr-only", children: "Notifications" }),
            /* @__PURE__ */ jsxs("div", { className: "relative", children: [
              /* @__PURE__ */ jsx("span", { className: "text-xl", children: "🔔" }),
              invitations && invitations.length > 0 && /* @__PURE__ */ jsx("span", { className: "absolute -top-1 -right-1 flex h-4 w-4 items-center justify-center rounded-full bg-[#F8B803] text-[10px] font-bold text-[#391800]", children: invitations.length })
            ] })
          ] }),
          /* @__PURE__ */ jsxs(DropdownMenuContent, { align: "end", className: "w-80 p-0 overflow-hidden bg-white/90 backdrop-blur-xl border-none shadow-2xl rounded-2xl", children: [
            /* @__PURE__ */ jsx("div", { className: "bg-[#D42426] p-4 text-white", children: /* @__PURE__ */ jsxs("h3", { className: "font-bold flex items-center gap-2", children: [
              "💌 Invitations ",
              invitations?.length ? `(${invitations.length})` : ""
            ] }) }),
            /* @__PURE__ */ jsx("div", { className: "max-h-[300px] overflow-y-auto p-2 space-y-2", children: invitations && invitations.length > 0 ? invitations.map((invite) => /* @__PURE__ */ jsxs("div", { className: "bg-white/50 rounded-xl p-3 border border-gray-100 shadow-sm", children: [
              /* @__PURE__ */ jsxs("div", { className: "mb-2", children: [
                /* @__PURE__ */ jsx("p", { className: "font-bold text-gray-800 text-sm", children: invite.group?.name }),
                /* @__PURE__ */ jsxs("p", { className: "text-xs text-gray-500", children: [
                  "Invité par ",
                  invite.group?.admin?.name
                ] })
              ] }),
              /* @__PURE__ */ jsxs("div", { className: "flex gap-2", children: [
                /* @__PURE__ */ jsxs(
                  Button,
                  {
                    onClick: () => handleAcceptInvitation(invite.id),
                    size: "sm",
                    className: "flex-1 bg-[#165B33] hover:bg-[#0f4224] text-white rounded-lg h-8 text-xs gap-1",
                    children: [
                      /* @__PURE__ */ jsx(Check, { className: "w-3 h-3" }),
                      " Accepter"
                    ]
                  }
                ),
                /* @__PURE__ */ jsxs(
                  Button,
                  {
                    onClick: () => handleDeclineInvitation(invite.id),
                    variant: "destructive",
                    size: "sm",
                    className: "flex-1 rounded-lg h-8 text-xs gap-1",
                    children: [
                      /* @__PURE__ */ jsx(X, { className: "w-3 h-3" }),
                      " Refuser"
                    ]
                  }
                )
              ] })
            ] }, invite.id)) : /* @__PURE__ */ jsx("div", { className: "p-4 text-center text-gray-500 text-sm italic", children: "Aucune nouvelle invitation." }) })
          ] })
        ] }),
        /* @__PURE__ */ jsxs(DropdownMenu, { children: [
          /* @__PURE__ */ jsxs(DropdownMenuTrigger, { className: "flex items-center gap-2 rounded-full bg-white/10 px-4 py-2 text-white backdrop-blur-sm transition-colors hover:bg-white/20 focus:outline-none", children: [
            /* @__PURE__ */ jsx("span", { className: "font-semibold", children: auth.user.name }),
            /* @__PURE__ */ jsx(ChevronDown, { className: "h-4 w-4" })
          ] }),
          /* @__PURE__ */ jsxs(DropdownMenuContent, { align: "end", className: "w-48", children: [
            /* @__PURE__ */ jsx(DropdownMenuItem, { asChild: true, children: /* @__PURE__ */ jsx(Link, { href: "/dashboard", className: "w-full cursor-pointer", children: "Tableau de Bord" }) }),
            /* @__PURE__ */ jsx(DropdownMenuItem, { asChild: true, children: /* @__PURE__ */ jsx(Link, { href: "/wishlists", className: "w-full cursor-pointer", children: "🎁 Mes Listes de Souhaits" }) }),
            /* @__PURE__ */ jsx(DropdownMenuItem, { asChild: true, children: /* @__PURE__ */ jsx(
              Link,
              {
                href: "/logout",
                method: "post",
                as: "button",
                className: "w-full cursor-pointer",
                children: "Déconnexion"
              }
            ) })
          ] })
        ] })
      ] }),
      !auth.user && /* @__PURE__ */ jsxs("div", { className: "relative z-10 flex min-h-screen flex-col items-center justify-center p-6 md:flex-row md:justify-around text-center md:text-left selection:bg-none", children: [
        /* @__PURE__ */ jsx("div", { className: "mb-10 md:mb-0 md:w-1/2 flex justify-center", children: /* @__PURE__ */ jsx("div", { className: "w-full max-w-[400px] md:max-w-full", children: /* @__PURE__ */ jsx(ChristmasTree, {}) }) }),
        /* @__PURE__ */ jsxs("div", { className: "flex flex-col items-center md:items-start md:w-1/2 md:pl-10", children: [
          /* @__PURE__ */ jsxs("div", { className: "mb-10 animate-fade-in-down", children: [
            /* @__PURE__ */ jsx("div", { className: "mb-4 text-6xl md:hidden", children: "🎅" }),
            /* @__PURE__ */ jsx("h1", { className: "font-christmas mb-2 text-6xl font-bold tracking-wide text-white drop-shadow-md sm:text-8xl", children: "Secret Santa" }),
            /* @__PURE__ */ jsx("p", { className: "mx-auto md:mx-0 max-w-lg text-lg text-red-100 sm:text-xl", children: "Organisez l'échange de cadeaux le plus magique avec vos amis et votre famille !" })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "flex flex-col gap-4 sm:flex-row sm:gap-6 animate-fade-in-up delay-200", children: [
            /* @__PURE__ */ jsx(
              Link,
              {
                href: "/login",
                className: "group relative inline-flex min-w-[160px] items-center justify-center overflow-hidden rounded-full bg-white px-8 py-3 font-bold text-[#D42426] shadow-lg transition-transform hover:scale-105 hover:bg-gray-50 focus:outline-none focus:ring-4 focus:ring-white/50",
                children: /* @__PURE__ */ jsx("span", { className: "relative z-10", children: "Connexion" })
              }
            ),
            canRegister && /* @__PURE__ */ jsx(
              Link,
              {
                href: "/register",
                className: "group relative inline-flex min-w-[160px] items-center justify-center overflow-hidden rounded-full bg-[#F8B803] px-8 py-3 font-bold text-[#391800] shadow-lg transition-transform hover:scale-105 hover:bg-[#e0a602] focus:outline-none focus:ring-4 focus:ring-[#F8B803]/50",
                children: /* @__PURE__ */ jsx("span", { className: "relative z-10", children: "Commencer" })
              }
            )
          ] })
        ] })
      ] }),
      auth.user && /* @__PURE__ */ jsxs("div", { className: "relative z-10 mx-auto flex min-h-screen max-w-7xl flex-col justify-center px-6 py-20", children: [
        /* @__PURE__ */ jsxs("div", { className: "mb-12 text-center animate-fade-in-down", children: [
          /* @__PURE__ */ jsx("h2", { className: "font-christmas text-5xl font-bold text-white drop-shadow-md sm:text-6xl", children: "Vos Groupes" }),
          /* @__PURE__ */ jsx("p", { className: "mt-4 text-xl text-red-100", children: "Retrouvez vos événements Secret Santa" }),
          /* @__PURE__ */ jsx("div", { className: "mt-8 flex justify-center", children: /* @__PURE__ */ jsxs(Dialog, { open: isCreateOpen, onOpenChange: setIsCreateOpen, children: [
            /* @__PURE__ */ jsx(DialogTrigger, { asChild: true, children: /* @__PURE__ */ jsx(Button, { className: "rounded-full bg-[#F8B803] px-8 py-6 text-lg font-bold text-[#391800] hover:bg-[#e0a602]", children: "+ Créer un Groupe" }) }),
            /* @__PURE__ */ jsx(DialogContent, { className: "sm:max-w-[480px] bg-transparent border-none shadow-none p-0 overflow-visible focus:outline-none", children: /* @__PURE__ */ jsxs("div", { className: "relative flex flex-col items-center", children: [
              /* @__PURE__ */ jsxs("div", { className: "relative w-full aspect-square rounded-full bg-gradient-to-b from-blue-50/50 to-white/40 backdrop-blur-md border-4 border-white/60 shadow-[0_0_50px_rgba(255,255,255,0.6)] flex flex-col items-center justify-center p-12 overflow-hidden z-10", children: [
                /* @__PURE__ */ jsx(DialogClose, { className: "absolute top-4 text-white/80 hover:text-white transition-colors z-50 rounded-full p-2 bg-black/20 hover:bg-black/30", children: /* @__PURE__ */ jsx(X, { className: "w-6 h-6" }) }),
                /* @__PURE__ */ jsxs("div", { className: "absolute inset-0 pointer-events-none", children: [
                  /* @__PURE__ */ jsx("div", { className: "absolute top-10 left-10 text-white/40 text-xs", children: "❄" }),
                  /* @__PURE__ */ jsx("div", { className: "absolute top-20 right-14 text-white/30 text-xl", children: "❅" }),
                  /* @__PURE__ */ jsx("div", { className: "absolute bottom-16 left-20 text-white/20 text-lg", children: "❄" })
                ] }),
                /* @__PURE__ */ jsxs(DialogHeader, { className: "mb-6 text-center relative z-20", children: [
                  /* @__PURE__ */ jsx(DialogTitle, { className: "font-christmas text-4xl text-[#D42426] drop-shadow-sm", children: "Créer un Nouveau Groupe" }),
                  /* @__PURE__ */ jsx(DialogDescription, { className: "text-slate-700 font-medium", children: "Donnez un nom à votre groupe pour commencer." })
                ] }),
                /* @__PURE__ */ jsxs("form", { onSubmit: createGroup, className: "w-full relative z-20", children: [
                  /* @__PURE__ */ jsxs("div", { className: "grid gap-4 py-4", children: [
                    /* @__PURE__ */ jsxs("div", { className: "flex flex-col gap-2", children: [
                      /* @__PURE__ */ jsx(Label, { htmlFor: "name", className: "text-center text-[#165B33] font-bold", children: "Nom du Groupe" }),
                      /* @__PURE__ */ jsx(
                        Input,
                        {
                          id: "name",
                          value: data.name,
                          onChange: (e) => setData("name", e.target.value),
                          className: "col-span-3 text-center bg-white/60 border-[#165B33]/30 focus:border-[#165B33] placeholder:text-slate-500 text-black",
                          placeholder: "Famille"
                        }
                      )
                    ] }),
                    errors.name && /* @__PURE__ */ jsx("div", { className: "text-center text-sm text-[#D42426] font-bold bg-white/80 rounded-full px-2 py-0.5", children: errors.name })
                  ] }),
                  /* @__PURE__ */ jsx(DialogFooter, { className: "justify-center sm:justify-center mt-2", children: /* @__PURE__ */ jsx(Button, { type: "submit", disabled: processing, className: "bg-[#D42426] hover:bg-[#b01e20] text-white rounded-full px-8 shadow-lg hover:scale-105 transition-transform", children: "Créer le Groupe" }) })
                ] })
              ] }),
              /* @__PURE__ */ jsx("div", { className: "w-[80%] h-24 bg-gradient-to-r from-[#8C1819] via-[#D42426] to-[#8C1819] rounded-b-[3rem] -mt-12 pt-16 relative z-0 border-x-4 border-b-4 border-[#391800]/20 shadow-2xl flex items-end justify-center pb-4", children: /* @__PURE__ */ jsx("div", { className: "text-[#F8B803] font-christmas text-xl opacity-80", children: "Ho Ho Ho !" }) })
            ] }) })
          ] }) })
        ] }),
        groups && groups.length > 0 ? /* @__PURE__ */ jsx("div", { className: "grid gap-6 sm:grid-cols-2 lg:grid-cols-3 animate-fade-in-up delay-100", children: groups.map((group) => /* @__PURE__ */ jsxs(
          Link,
          {
            href: `/groups/${group.id}`,
            className: "group relative block overflow-hidden rounded-xl bg-white/10 backdrop-blur-md transition-all hover:-translate-y-1 hover:bg-white/20 hover:shadow-xl focus:outline-none focus:ring-2 focus:ring-[#F8B803]",
            children: [
              /* @__PURE__ */ jsxs("div", { className: "p-6", children: [
                /* @__PURE__ */ jsx("div", { className: "mb-4 flex h-12 w-12 items-center justify-center rounded-full bg-[#165B33] text-2xl shadow-lg", children: "🎁" }),
                /* @__PURE__ */ jsx("h3", { className: "mb-2 text-xl font-bold text-white", children: group.name }),
                /* @__PURE__ */ jsxs("p", { className: "mb-6 text-sm text-red-100", children: [
                  "Échange de cadeaux : ",
                  new Date(group.event_date).toLocaleDateString("fr-FR", { dateStyle: "long" })
                ] }),
                /* @__PURE__ */ jsxs(
                  "div",
                  {
                    className: "inline-flex items-center gap-2 text-sm font-semibold text-[#F8B803] transition-colors group-hover:text-[#ffd666]",
                    children: [
                      "Voir le Groupe",
                      /* @__PURE__ */ jsx("span", { "aria-hidden": "true", children: "→" })
                    ]
                  }
                )
              ] }),
              /* @__PURE__ */ jsx("div", { className: "absolute -bottom-6 -right-6 h-24 w-24 rounded-full bg-[#D42426]/30 blur-2xl transition-all group-hover:bg-[#D42426]/50" })
            ]
          },
          group.id
        )) }) : /* @__PURE__ */ jsx("div", { className: "text-center text-white/80 animate-fade-in-up", children: /* @__PURE__ */ jsx("p", { className: "text-lg", children: "Vous n'avez pas encore rejoint de groupe." }) })
      ] })
    ] })
  ] });
}
export {
  Welcome as default
};
