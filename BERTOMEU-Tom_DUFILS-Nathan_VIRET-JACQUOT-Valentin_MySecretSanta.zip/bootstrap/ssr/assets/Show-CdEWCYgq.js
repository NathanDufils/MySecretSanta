import { jsxs, jsx } from "react/jsx-runtime";
import { usePage, useForm, Head, Link, router } from "@inertiajs/react";
import { u as useSnowflakes } from "./useSnowflakes-Cquv3aof.js";
import { ChevronLeft, Settings, Trash2, UserPlus, X, Gift } from "lucide-react";
import { D as Dialog, a as DialogTrigger, b as DialogContent, c as DialogHeader, d as DialogTitle, e as DialogDescription, f as DialogFooter, g as DialogClose } from "./dialog-Dfe6QsSy.js";
import { B as Button } from "./button-BgedwMt5.js";
import { L as Label, I as Input } from "./label-C5ThrQzA.js";
import { useState } from "react";
import "@radix-ui/react-dialog";
import "@radix-ui/react-slot";
import "class-variance-authority";
import "clsx";
import "tailwind-merge";
import "@radix-ui/react-label";
function GroupShow({ group, participants, draw, userWishlists }) {
  const { auth } = usePage().props;
  const snowflakes = useSnowflakes(20);
  const isAdmin = group.admin_id === auth.user.id;
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isInviteOpen, setIsInviteOpen] = useState(false);
  const [wishlistLoading, setWishlistLoading] = useState(false);
  const handleAssign = (wishlistId) => {
    setWishlistLoading(true);
    router.post(`/groups/${group.id}/wishlist`, { wishlist_id: wishlistId }, {
      onFinish: () => setWishlistLoading(false),
      preserveScroll: true
    });
  };
  const updateForm = useForm({
    description: group.description || "",
    event_date: group.event_date ? new Date(group.event_date).toISOString().split("T")[0] : ""
  });
  const inviteForm = useForm({
    email: ""
  });
  const handleUpdate = (e) => {
    e.preventDefault();
    updateForm.put(`/groups/${group.id}`, {
      onSuccess: () => setIsSettingsOpen(false)
    });
  };
  const handleInvite = (e) => {
    e.preventDefault();
    inviteForm.post(`/groups/${group.id}/participants`, {
      onSuccess: () => {
        setIsInviteOpen(false);
        inviteForm.reset();
      }
    });
  };
  const handleRemove = (userId) => {
    if (confirm("Êtes-vous sûr de vouloir retirer ce membre ?")) {
      router.delete(`/groups/${group.id}/participants/${userId}`);
    }
  };
  const handleDraw = () => {
    if (confirm("Lancer le tirage ? Cette action est irréversible.")) {
      router.post(`/groups/${group.id}/draw`);
    }
  };
  const myWishlist = participants.find((p) => p.id === auth.user.id)?.assigned_wishlist;
  return /* @__PURE__ */ jsxs("div", { className: "relative min-h-screen overflow-hidden bg-gradient-to-b from-[#D42426] to-[#8C1819] text-white selection:bg-[#F8B803] selection:text-[#391800] pb-20", children: [
    /* @__PURE__ */ jsx(Head, { title: `${group.name} - Secret Santa` }),
    /* @__PURE__ */ jsx("style", { children: `
                @import url('https://fonts.googleapis.com/css2?family=Mountains+of+Christmas:wght@400;700&display=swap');
                .font-christmas { font-family: 'Mountains of Christmas', cursive; }
                .snowflake { position: absolute; top: -3vh; color: white; animation: fall linear infinite; }
                @keyframes fall {
                    0% { transform: translateY(-10vh) translateX(0px); opacity: 0; }
                    10% { opacity: 0.8; }
                    100% { transform: translateY(100vh) translateX(20px); opacity: 0.3; }
                }
            ` }),
    /* @__PURE__ */ jsx("div", { "aria-hidden": "true", className: "pointer-events-none absolute inset-0 z-0 select-none", children: snowflakes.map((flake, i) => /* @__PURE__ */ jsx("div", { className: "snowflake text-xl", style: flake, children: "❄" }, i)) }),
    /* @__PURE__ */ jsxs("div", { className: "relative z-10 mx-auto max-w-7xl px-6 pt-10", children: [
      /* @__PURE__ */ jsxs("div", { className: "mb-10 flex flex-col items-center text-center", children: [
        /* @__PURE__ */ jsxs(
          Link,
          {
            href: "/",
            className: "mb-6 flex items-center gap-2 self-start rounded-full bg-white/10 px-4 py-2 text-sm font-semibold backdrop-blur-sm transition-colors hover:bg-white/20",
            children: [
              /* @__PURE__ */ jsx(ChevronLeft, { className: "h-4 w-4" }),
              "Retour à l'Accueil"
            ]
          }
        ),
        /* @__PURE__ */ jsx("h1", { className: "font-christmas mb-2 text-5xl font-bold text-white drop-shadow-md sm:text-7xl", children: group.name }),
        /* @__PURE__ */ jsxs("p", { className: "text-red-100 mb-4", children: [
          "Échange de cadeaux : ",
          new Date(group.event_date).toLocaleDateString("fr-FR", { dateStyle: "long" })
        ] }),
        /* @__PURE__ */ jsx("div", { className: "mb-6 inline-flex items-center gap-3 rounded-xl bg-white/20 px-6 py-3 backdrop-blur-md border border-white/30 shadow-lg", children: /* @__PURE__ */ jsxs("div", { className: "text-right", children: [
          /* @__PURE__ */ jsx("p", { className: "text-xs font-bold text-white/60 uppercase tracking-widest", children: "Code Groupe" }),
          /* @__PURE__ */ jsx("p", { className: "text-2xl font-mono font-bold text-[#F8B803] tracking-wider select-all", children: group.code })
        ] }) }),
        group.description && /* @__PURE__ */ jsx("p", { className: "text-white/80 max-w-2xl mb-6", children: group.description }),
        isAdmin && /* @__PURE__ */ jsxs("div", { className: "flex gap-4", children: [
          /* @__PURE__ */ jsxs(Dialog, { open: isSettingsOpen, onOpenChange: setIsSettingsOpen, children: [
            /* @__PURE__ */ jsx(DialogTrigger, { asChild: true, children: /* @__PURE__ */ jsxs(Button, { variant: "secondary", className: "gap-2", children: [
              /* @__PURE__ */ jsx(Settings, { className: "h-4 w-4" }),
              " Paramètres"
            ] }) }),
            /* @__PURE__ */ jsxs(DialogContent, { className: "text-black sm:max-w-[425px]", children: [
              /* @__PURE__ */ jsxs(DialogHeader, { children: [
                /* @__PURE__ */ jsx(DialogTitle, { children: "Paramètres du Groupe" }),
                /* @__PURE__ */ jsx(DialogDescription, { children: "Modifier les détails du groupe." })
              ] }),
              /* @__PURE__ */ jsxs("form", { onSubmit: handleUpdate, children: [
                /* @__PURE__ */ jsxs("div", { className: "grid gap-4 py-4", children: [
                  /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-4 items-center gap-4", children: [
                    /* @__PURE__ */ jsx(Label, { htmlFor: "date", className: "text-right", children: "Date" }),
                    /* @__PURE__ */ jsx(Input, { id: "date", type: "date", className: "col-span-3", value: updateForm.data.event_date, onChange: (e) => updateForm.setData("event_date", e.target.value) })
                  ] }),
                  /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-4 items-center gap-4", children: [
                    /* @__PURE__ */ jsx(Label, { htmlFor: "desc", className: "text-right", children: "Description" }),
                    /* @__PURE__ */ jsx(Input, { id: "desc", className: "col-span-3", value: updateForm.data.description, onChange: (e) => updateForm.setData("description", e.target.value) })
                  ] })
                ] }),
                /* @__PURE__ */ jsxs("div", { className: "mt-4 border-t border-gray-100 pt-4", children: [
                  /* @__PURE__ */ jsx("h4", { className: "text-sm font-semibold text-red-600 mb-2", children: "Zone Danger" }),
                  /* @__PURE__ */ jsxs(
                    Button,
                    {
                      type: "button",
                      variant: "destructive",
                      className: "w-full bg-red-100 text-red-600 hover:bg-red-200",
                      onClick: () => {
                        if (confirm("Êtes-vous ABSOLUMENT sûr ? Cette action supprimera le groupe et toutes les données associées.")) {
                          router.delete(`/groups/${group.id}`);
                        }
                      },
                      children: [
                        /* @__PURE__ */ jsx(Trash2, { className: "mr-2 h-4 w-4" }),
                        "Supprimer ce Groupe"
                      ]
                    }
                  )
                ] }),
                /* @__PURE__ */ jsx(DialogFooter, { children: /* @__PURE__ */ jsx(Button, { type: "submit", className: "bg-[#D42426] text-white hover:bg-[#b01e20]", children: "Enregistrer" }) })
              ] })
            ] })
          ] }),
          /* @__PURE__ */ jsxs(Dialog, { open: isInviteOpen, onOpenChange: setIsInviteOpen, children: [
            /* @__PURE__ */ jsx(DialogTrigger, { asChild: true, children: /* @__PURE__ */ jsxs(Button, { variant: "secondary", className: "gap-2", disabled: group.status !== "open", children: [
              /* @__PURE__ */ jsx(UserPlus, { className: "h-4 w-4" }),
              " Inviter un Membre"
            ] }) }),
            /* @__PURE__ */ jsx(DialogContent, { className: "sm:max-w-[480px] bg-transparent border-none shadow-none p-0 overflow-visible focus:outline-none", children: /* @__PURE__ */ jsxs("div", { className: "relative flex flex-col items-center", children: [
              /* @__PURE__ */ jsxs("div", { className: "relative w-full aspect-square rounded-full bg-gradient-to-b from-blue-50/50 to-white/40 backdrop-blur-md border-4 border-white/60 shadow-[0_0_50px_rgba(255,255,255,0.6)] flex flex-col items-center justify-center p-12 overflow-hidden z-10", children: [
                /* @__PURE__ */ jsx(DialogClose, { className: "absolute top-10 text-white/80 hover:text-white transition-colors z-50 rounded-full p-2 bg-black/20 hover:bg-black/30", children: /* @__PURE__ */ jsx(X, { className: "w-6 h-6" }) }),
                /* @__PURE__ */ jsxs("div", { className: "absolute inset-0 pointer-events-none", children: [
                  /* @__PURE__ */ jsx("div", { className: "absolute top-10 left-10 text-white/40 text-xs", children: "❄" }),
                  /* @__PURE__ */ jsx("div", { className: "absolute top-20 right-14 text-white/30 text-xl", children: "❅" }),
                  /* @__PURE__ */ jsx("div", { className: "absolute bottom-16 left-20 text-white/20 text-lg", children: "❄" })
                ] }),
                /* @__PURE__ */ jsxs(DialogHeader, { className: "mb-6 text-center relative z-20", children: [
                  /* @__PURE__ */ jsx(DialogTitle, { className: "font-christmas text-4xl text-[#D42426] drop-shadow-sm", children: "Inviter un Membre" }),
                  /* @__PURE__ */ jsx(DialogDescription, { className: "text-slate-700 font-medium", children: "Envoyez une invitation par email pour rejoindre le groupe." })
                ] }),
                /* @__PURE__ */ jsxs("form", { onSubmit: handleInvite, className: "w-full relative z-20", children: [
                  /* @__PURE__ */ jsxs("div", { className: "grid gap-4 py-4", children: [
                    /* @__PURE__ */ jsxs("div", { className: "flex flex-col gap-2", children: [
                      /* @__PURE__ */ jsx(Label, { htmlFor: "email", className: "text-center text-[#165B33] font-bold", children: "Adresse Email" }),
                      /* @__PURE__ */ jsx(
                        Input,
                        {
                          id: "email",
                          type: "email",
                          required: true,
                          value: inviteForm.data.email,
                          onChange: (e) => inviteForm.setData("email", e.target.value),
                          className: "col-span-3 text-center bg-white/60 border-[#165B33]/30 focus:border-[#165B33] placeholder:text-slate-500 text-black",
                          placeholder: "santa@northpole.com"
                        }
                      )
                    ] }),
                    inviteForm.errors.email && /* @__PURE__ */ jsx("p", { className: "text-center text-sm text-[#D42426] font-bold bg-white/80 rounded-full px-2 py-0.5", children: inviteForm.errors.email })
                  ] }),
                  /* @__PURE__ */ jsx(DialogFooter, { className: "justify-center sm:justify-center mt-2", children: /* @__PURE__ */ jsx(Button, { type: "submit", disabled: inviteForm.processing, className: "bg-[#D42426] hover:bg-[#b01e20] text-white rounded-full px-8 shadow-lg hover:scale-105 transition-transform", children: "Envoyer l'invitation" }) })
                ] })
              ] }),
              /* @__PURE__ */ jsx("div", { className: "w-[80%] h-24 bg-gradient-to-r from-[#8C1819] via-[#D42426] to-[#8C1819] rounded-b-[3rem] -mt-12 pt-16 relative z-0 border-x-4 border-b-4 border-[#391800]/20 shadow-2xl flex items-end justify-center pb-4", children: /* @__PURE__ */ jsx("div", { className: "text-[#F8B803] font-christmas text-xl opacity-80", children: "Ho Ho Ho !" }) })
            ] }) })
          ] }),
          group.status === "open" && /* @__PURE__ */ jsxs(
            Button,
            {
              onClick: handleDraw,
              className: "bg-[#F8B803] text-[#391800] hover:bg-[#e0a602] font-bold gap-2",
              disabled: participants.length < 3,
              children: [
                /* @__PURE__ */ jsx(Gift, { className: "h-4 w-4" }),
                "Lancer le Tirage"
              ]
            }
          )
        ] })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "grid gap-8 lg:grid-cols-2", children: [
        /* @__PURE__ */ jsxs("div", { className: "flex flex-col gap-8", children: [
          /* @__PURE__ */ jsxs("div", { className: "rounded-2xl bg-[#165B33] p-8 shadow-xl border-4 border-[#F8B803]/50 relative overflow-hidden group hover:scale-[1.02] transition-transform", children: [
            /* @__PURE__ */ jsxs("div", { className: "relative z-10", children: [
              /* @__PURE__ */ jsx("h2", { className: "font-christmas mb-4 text-3xl font-bold text-[#F8B803]", children: "🤫 Votre Mission Secrète" }),
              draw ? /* @__PURE__ */ jsxs("div", { children: [
                /* @__PURE__ */ jsx("p", { className: "mb-2 text-lg text-green-100", children: "Vous devez préparer un cadeau pour :" }),
                /* @__PURE__ */ jsx("div", { className: "text-4xl font-bold text-white mb-4", children: draw.target?.name }),
                /* @__PURE__ */ jsxs("div", { className: "rounded-lg bg-black/20 p-4", children: [
                  /* @__PURE__ */ jsx("p", { className: "mb-2 text-sm font-semibold uppercase tracking-wider text-[#F8B803]", children: "Sa Liste de Souhaits" }),
                  /* @__PURE__ */ jsx("ul", { className: "list-inside list-disc space-y-1 text-green-50", children: participants.find((p) => p.id === draw.target_id)?.assigned_wishlist?.items?.length ? participants.find((p) => p.id === draw.target_id)?.assigned_wishlist?.items.map((item) => /* @__PURE__ */ jsxs("li", { children: [
                    /* @__PURE__ */ jsx("span", { className: "font-medium", children: item.name }),
                    item.url && /* @__PURE__ */ jsx("a", { href: item.url, target: "_blank", rel: "noreferrer", className: "ml-2 text-xs text-[#F8B803] underline", children: "Lien" })
                  ] }, item.id)) : /* @__PURE__ */ jsx("li", { className: "italic opacity-70", children: "Aucun cadeau ajouté pour le moment..." }) })
                ] })
              ] }) : /* @__PURE__ */ jsx("p", { className: "text-xl text-white", children: "Le tirage n'a pas encore eu lieu ! Revenez plus tard." })
            ] }),
            /* @__PURE__ */ jsx("div", { className: "absolute top-0 right-0 -mt-10 -mr-10 h-40 w-40 rounded-full bg-white/10 blur-3xl opacity-50" })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "rounded-2xl bg-white/10 backdrop-blur-md p-8 shadow-lg border border-white/20", children: [
            /* @__PURE__ */ jsx("h2", { className: "font-christmas mb-4 text-3xl font-bold text-white", children: "📝 Votre Liste de Souhaits" }),
            /* @__PURE__ */ jsxs("div", { className: "mb-6", children: [
              /* @__PURE__ */ jsx("label", { className: "block text-sm font-medium text-white/80 mb-2", children: "Choisir la liste pour ce groupe :" }),
              /* @__PURE__ */ jsxs(
                "select",
                {
                  className: "w-full rounded-lg bg-white/20 border-white/10 text-white focus:ring-[#F8B803] focus:border-[#F8B803] focus:bg-white/30 transition-colors",
                  value: myWishlist?.id || "",
                  onChange: (e) => handleAssign(e.target.value),
                  disabled: wishlistLoading,
                  children: [
                    /* @__PURE__ */ jsx("option", { value: "", className: "text-black", children: "-- Aucune liste sélectionnée --" }),
                    userWishlists.map((list) => /* @__PURE__ */ jsxs("option", { value: list.id, className: "text-black", children: [
                      list.title,
                      " (",
                      list.items?.length || 0,
                      " objets)"
                    ] }, list.id))
                  ]
                }
              )
            ] }),
            myWishlist?.items && myWishlist.items.length > 0 ? /* @__PURE__ */ jsx("ul", { className: "space-y-3 mb-6 max-h-60 overflow-y-auto pr-2 scrollbar-thin scrollbar-thumb-white/30 scrollbar-track-transparent", children: myWishlist.items.map((item) => /* @__PURE__ */ jsxs("li", { className: "flex items-center gap-3 rounded-lg bg-white/5 p-3 hover:bg-white/10 transition-colors", children: [
              /* @__PURE__ */ jsx("span", { className: "text-2xl", children: "🎁" }),
              /* @__PURE__ */ jsxs("div", { className: "flex-1 min-w-0", children: [
                /* @__PURE__ */ jsx("p", { className: "font-semibold truncate", children: item.name }),
                item.url && /* @__PURE__ */ jsxs("a", { href: item.url, target: "_blank", rel: "noreferrer", className: "text-xs text-[#F8B803] hover:underline truncate block flex items-center gap-1", children: [
                  /* @__PURE__ */ jsx(Gift, { className: "w-3 h-3 inline" }),
                  " Voir le lien"
                ] })
              ] })
            ] }, item.id)) }) : /* @__PURE__ */ jsxs("div", { className: "text-center py-6 mb-4", children: [
              /* @__PURE__ */ jsx("p", { className: "text-red-100 italic mb-2", children: "Aucune liste active." }),
              /* @__PURE__ */ jsx("p", { className: "text-sm text-white/60", children: "Sélectionnez une liste ci-dessus ou créez-en une nouvelle." })
            ] }),
            /* @__PURE__ */ jsx(Link, { href: "/wishlists", className: "block w-full text-center rounded-full bg-white py-3 font-bold text-[#D42426] hover:bg-gray-100 transition-colors shadow-md hover:scale-[1.02] active:scale-95", children: "Gérer mes Listes" })
          ] })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "rounded-2xl bg-white/10 backdrop-blur-md p-8 shadow-lg border border-white/20", children: [
          /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between mb-6", children: [
            /* @__PURE__ */ jsxs("h2", { className: "font-christmas text-3xl font-bold text-white", children: [
              "👥 Participants (",
              participants.length,
              ")"
            ] }),
            /* @__PURE__ */ jsx("span", { className: "text-2xl", children: "🎄" })
          ] }),
          /* @__PURE__ */ jsx("div", { className: "grid gap-4", children: participants.map((participant) => /* @__PURE__ */ jsxs("div", { className: `flex items-start gap-4 rounded-xl p-4 transition-all ${participant.id === auth.user.id ? "bg-[#F8B803]/20 border border-[#F8B803]/50" : "bg-white/5 border border-white/10"}`, children: [
            /* @__PURE__ */ jsx("div", { className: "flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-white/20 text-lg font-bold", children: participant.name.charAt(0) }),
            /* @__PURE__ */ jsxs("div", { className: "flex-1 min-w-0", children: [
              /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between", children: [
                /* @__PURE__ */ jsxs("h3", { className: "font-bold truncate text-lg", children: [
                  participant.name,
                  " ",
                  participant.id === auth.user.id && "(Vous)"
                ] }),
                isAdmin && participant.id !== auth.user.id && group.status === "open" && /* @__PURE__ */ jsx(
                  "button",
                  {
                    onClick: () => handleRemove(participant.id),
                    className: "text-white/50 hover:text-red-300 transition-colors",
                    title: "Retirer le membre",
                    children: /* @__PURE__ */ jsx(Trash2, { className: "h-4 w-4" })
                  }
                )
              ] }),
              /* @__PURE__ */ jsxs("div", { className: "mt-2", children: [
                /* @__PURE__ */ jsx("p", { className: "text-xs font-semibold uppercase tracking-wider text-white/60 mb-1", children: "Liste :" }),
                participant.assigned_wishlist?.items && participant.assigned_wishlist.items.length > 0 ? /* @__PURE__ */ jsx("ul", { className: "text-sm space-y-1 text-red-50", children: participant.assigned_wishlist?.items.map((item) => /* @__PURE__ */ jsxs("li", { className: "flex items-center gap-1.5 truncate", children: [
                  /* @__PURE__ */ jsx("span", { className: "block h-1.5 w-1.5 rounded-full bg-[#F8B803]" }),
                  item.name
                ] }, item.id)) }) : /* @__PURE__ */ jsx("p", { className: "text-sm italic text-white/40", children: "Vide..." })
              ] })
            ] })
          ] }, participant.id)) })
        ] })
      ] })
    ] })
  ] });
}
export {
  GroupShow as default
};
