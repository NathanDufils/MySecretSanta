import { jsx } from "react/jsx-runtime";
import { createInertiaApp } from "@inertiajs/react";
import createServer from "@inertiajs/react/server";
import ReactDOMServer from "react-dom/server";
async function resolvePageComponent(path, pages) {
  for (const p of Array.isArray(path) ? path : [path]) {
    const page = pages[p];
    if (typeof page === "undefined") {
      continue;
    }
    return typeof page === "function" ? page() : page;
  }
  throw new Error(`Page not found: ${path}`);
}
const appName = "Laravel";
createServer(
  (page) => createInertiaApp({
    page,
    render: ReactDOMServer.renderToString,
    title: (title) => title || appName,
    resolve: (name) => resolvePageComponent(
      `./pages/${name}.tsx`,
      /* @__PURE__ */ Object.assign({ "./pages/Groups/Show.tsx": () => import("./assets/Show-CdEWCYgq.js"), "./pages/Wishlists/Index.tsx": () => import("./assets/Index-Dvzb8B17.js"), "./pages/auth/confirm-password.tsx": () => import("./assets/confirm-password-C3cSZZ0u.js"), "./pages/auth/forgot-password.tsx": () => import("./assets/forgot-password-DpJJeu3t.js"), "./pages/auth/login.tsx": () => import("./assets/login-DNSo0Ixv.js"), "./pages/auth/register.tsx": () => import("./assets/register-DCz9xSkI.js"), "./pages/auth/reset-password.tsx": () => import("./assets/reset-password-BikD6IPb.js"), "./pages/auth/verify-email.tsx": () => import("./assets/verify-email-CedxAk7j.js"), "./pages/dashboard.tsx": () => import("./assets/dashboard-CjFb2ssc.js"), "./pages/settings/appearance.tsx": () => import("./assets/appearance-Bi8hH4xH.js"), "./pages/settings/password.tsx": () => import("./assets/password-GOqtdgSD.js"), "./pages/settings/profile.tsx": () => import("./assets/profile-CtadU_3m.js"), "./pages/welcome.tsx": () => import("./assets/welcome-C9SFTZ5W.js") })
    ),
    setup: ({ App, props }) => {
      return /* @__PURE__ */ jsx(App, { ...props });
    }
  })
);
