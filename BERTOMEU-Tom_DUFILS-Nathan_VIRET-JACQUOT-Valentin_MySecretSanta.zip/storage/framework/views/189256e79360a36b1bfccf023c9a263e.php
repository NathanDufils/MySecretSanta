<section
    <?php echo e($attributes->merge(['class' => "w-full max-w-7xl mx-auto p-4 sm:p-14 border-x border-dashed border-neutral-300 dark:border-white/[9%]"])); ?>

>
    <?php echo e($slot); ?>

</section>
<?php /**PATH M:\Workspace\02_Etudes\2025-2026_BUT3-BIS\Semestre_5_BIS\Développement_Avancé\PHP\MySecretSanta\MySecretSanta\vendor\laravel\framework\src\Illuminate\Foundation\Providers/../resources/exceptions/renderer/components/section-container.blade.php ENDPATH**/ ?>