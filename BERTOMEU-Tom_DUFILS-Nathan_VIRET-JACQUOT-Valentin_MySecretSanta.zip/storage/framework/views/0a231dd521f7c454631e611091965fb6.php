<?php $__env->startSection('title', __('Too Many Requests')); ?>
<?php $__env->startSection('code', '429'); ?>
<?php $__env->startSection('message', __('Too Many Requests')); ?>

<?php echo $__env->make('errors::minimal', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH M:\Workspace\02_Etudes\2025-2026_BUT3-BIS\Semestre_5_BIS\Développement_Avancé\PHP\MySecretSanta\MySecretSanta\vendor\laravel\framework\src\Illuminate\Foundation\Exceptions/views/429.blade.php ENDPATH**/ ?>